CREATE TRIGGER DBUSER.EMPLOYEE_AUDIT
AFTER DELETE    
   ON DBUSER.EMPLOYEE FOR EACH ROW
   
    DECLARE
    userName DBUSER.manager.manager_name%TYPE;
   
    BEGIN
   -- Find username of person performing the INSERT into table
   SELECT manager_name INTO userName from DBUSER.MANAGER  where manager_ID = 1;

   -- Insert record into Employee audit table
   INSERT INTO DBUSER.EMPLOYEE_AUDIT
   ( USERNAME,  ACTION_PERFORMED, DATETIME )
   VALUES
   ( userName, "DELETE",SYSDATE() );

END; 


CREATE TRIGGER DBUSER.EMPLOYEE_AUDIT
AFTER INSERT    
   ON DBUSER.EMPLOYEE FOR EACH ROW
   
    DECLARE
    userName DBUSER.manager.manager_name%TYPE;
   
    BEGIN
   -- Find username of person performing the INSERT into table
   SELECT manager_name INTO userName from DBUSER.MANAGER  where manager_ID = 1;

   -- Insert record into Employee audit table
   INSERT INTO DBUSER.EMPLOYEE_AUDIT
   ( USERNAME,  ACTION_PERFORMED, DATETIME )
   VALUES
   ( userName, "INSERT",SYSDATE() );

END; 

CREATE TRIGGER DBUSER.EMPLOYEE_AUDIT
AFTER UPDATE    
   ON DBUSER.EMPLOYEE FOR EACH ROW
   
    DECLARE
    userName DBUSER.manager.manager_name%TYPE;
   
    BEGIN
   -- Find username of person performing the INSERT into table
   SELECT manager_name INTO userName from DBUSER.MANAGER  where manager_ID = 1;

   -- Insert record into Employee audit table
   INSERT INTO DBUSER.EMPLOYEE_AUDIT
   ( USERNAME,  ACTION_PERFORMED, DATETIME )
   VALUES
   ( userName, "UPDATE",SYSDATE() );

END; 

